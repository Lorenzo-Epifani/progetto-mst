const mongoose = require('mongoose');
var crypto = require('crypto')
SALT = "mysalt"

function hash_psw(psw,salt){
    var shasum = crypto.createHash('sha1')
    const pswstring = `${salt}_${psw}` 
    shasum.update(pswstring)
    return shasum.digest('hex') 
}

// MONGO CONN
async function connectDB() {
    try {
        await mongoose.connect('mongodb://localhost:27017/sketch_db', {
            useNewUrlParser: true,
            useUnifiedTopology: true,
        });
        console.log('Connected');
    } catch (error) {
        console.error('Error MongoDB:', error);
        process.exit(1);
    }
}

// SCHEMAS
const UserSchema = new mongoose.Schema({
    ID: { type: Number, required: true, unique: true },
    nome: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    ruolo: { type: Number, default: 1 },
}, { collection: 'utente', timestamps: false });

const FotoSchema = new mongoose.Schema({
    ID: { type: Number, required: true, unique: true },
    titolo: { type: String },
    url: { type: String },
    Utente_ID: { type: Number, ref: 'User', required: true },
}, { collection: 'foto', timestamps: false });

const LikeSchema = new mongoose.Schema({
    Utente_ID: { type: Number, ref: 'User', required: true },
    Foto_ID: { type: Number, ref: 'Foto', required: true },
}, { collection: 'like', timestamps: false });

// UNIQUE INDEXES FOR LIKE
LikeSchema.index({ Utente_ID: 1, Foto_ID: 1 }, { unique: true });

// MODELS
const User = mongoose.model('User', UserSchema);
const Foto = mongoose.model('Foto', FotoSchema);
const Like = mongoose.model('Like', LikeSchema);

// INSERT
async function insertData() {
    try {
        // 
        await User.insertMany([
            { ID: 1, nome: 'user1', password: 'pass1', ruolo: 1 },
            { ID: 2, nome: 'user2', password: 'pass2', ruolo: 1 },
            { ID: 3, nome: 'user3', password: 'pass3', ruolo: 1 },
            { ID: 4, nome: 'user4', password: 'pass4', ruolo: 1 },
            { ID: 5, nome: 'user5', password: 'pass5', ruolo: 1 },
            { ID: 6, nome: 'user6', password: 'pass6', ruolo: 1 },
            { ID: 7, nome: 'user7', password: 'pass7', ruolo: 1 },
            { ID: 8, nome: 'user8', password: 'pass8', ruolo: 1 },
            { ID: 9, nome: 'user9', password: 'pass9', ruolo: 1 },
            { ID: 10, nome: 'user10', password: 'pass10', ruolo: 1 },
        ].map(x=>{
            x.password=hash_psw(x.password,SALT)
            return x
        }));
        console.log('USER INIT OK');
        
        // 
        await Foto.insertMany([
            { ID: 1, titolo: 'Foto1', url: 'logo2.jpg', Utente_ID: 1 },
            { ID: 2, titolo: 'Foto2', url: 'logo3.jpg', Utente_ID: 2 },
            { ID: 3, titolo: 'Foto3', url: 'logo4.jpg', Utente_ID: 3 },
        ]);
        console.log('PIC INIT OK');
        
        // 
        await Like.insertMany([
            { Utente_ID: 1, Foto_ID: 1 },
            { Utente_ID: 2, Foto_ID: 1 },
            { Utente_ID: 3, Foto_ID: 1 },
            { Utente_ID: 4, Foto_ID: 2 },
            { Utente_ID: 5, Foto_ID: 2 },
            { Utente_ID: 6, Foto_ID: 2 },
            { Utente_ID: 7, Foto_ID: 3 },
            { Utente_ID: 8, Foto_ID: 3 },
            { Utente_ID: 9, Foto_ID: 3 },
            { Utente_ID: 10, Foto_ID: 1 },
        ]);
        console.log('LIKE OK');
    } catch (error) {
        console.error('INSERT ERROR:', error);
    }
}

// START
async function main() {
    await connectDB();
    await insertData();
    mongoose.connection.close();
}

main();