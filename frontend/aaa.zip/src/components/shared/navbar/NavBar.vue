<template>
    <div id="navbar" class="md-elevation-14">
        <md-tabs class="md-accent" md-alignment="right">
            <!-- Bottone Home -->
            <md-tab
            id="tab-home"
            md-label="Home"
            md-icon="dashboard"
            @click="goTo('/home')"
            ></md-tab>
            
            <!-- Bottone Login o Profilo -->
            <md-tab
            v-if="!sessionToken"
            id="tab-login"
            md-label="Login"
            md-icon="login"
            @click="goTo('/login')"
            ></md-tab>
            <md-tab
            v-else
            id="tab-profile"
            md-label="MyProfile"
            md-icon="accessibility"
            @click="goTo('/profile')"
            ></md-tab>
        </md-tabs>
    </div>
</template>

<script>
export default {
    name: "NavBar",
    data() {
        return {
            sessionToken: null, // Memorizza il token di sessione
        };
    },
    created() {
        // Ottieni il sessionToken da localStorage
        this.sessionToken = localStorage.getItem("sessionToken");
    },
    methods: {
        goTo(route) {
            if (this.$route.path !== route) {
                this.$router.push(route);
            }
        }
    },
};
</script>

<style>
.md-tabs {
    margin-top: 8px;
    background-color: darkblue;
}

div#navbar .md-button-content {
    font-weight: bold;
    font-size: 150%;
    color: white;
}

div#navbar .md-button-content:hover {
    animation: lds-beat 0.4s cubic-bezier(0, 0.2, 0.8, 1) infinite;
}

@keyframes lds-beat {
    0%,
    100% {
        transform: scale(1);
        opacity: 1;
    }
    40% {
        transform: scale(0.97);
        opacity: 0.7;
    }
    80% {
        transform: scale(1.03);
        opacity: 1;
    }
}
</style>
